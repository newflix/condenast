1.open node project in vs code(project folder which contains package.json)
------------------------------------------------------------------------------

2.npm install

------------------------------------------------------------------------------

//to start server
3.nodemon .\bin\server.js

//server will be listening at port 5000
------------------------------------------------------------------------------