1. open the client project folder in vs code

2. on terminal run

npm install

3. npm start
//react app server will run at localhost:3000



project contains following components

1]Header
2]NewsMenu(added for temporary purpose, this is not implemented)
3]SearchBar
4]ArticleList


--------------------------------------------------------------------------------
once node server is running at localhost:5000
user can visit localhost
by default, uk top headlines will be shown
then user can search for news,search news will return last 3 week old news
-----------------------------------------------------------------------------